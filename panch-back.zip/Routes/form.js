const express = require("express")
const { getUserById } = require("../Controller/user")
const { getFormById, createForm, getForm, removeForm, editForm, getAllForms } = require("../Controller/form")
const { isAuthenticated, isSignedIn } = require("../Controller/auth")
const router = express.Router()

router.param("userId", getUserById)
router.param("formId", getFormById)


router.post("/form/create/:userId", isAuthenticated, isSignedIn, createForm)

router.get("/form/:formId",  getForm)

router.delete("/form/:userId/:formId", isAuthenticated, isSignedIn, removeForm)

router.put("/form/:userId/:formId", isAuthenticated, isSignedIn, editForm)

router.get("/forms/:userId", isAuthenticated, isSignedIn, getAllForms)

module.exports = router